import React from 'react'
// import AppointmentList from './AppointmentList'
import AvailableSlots from './AvailableSlots'
function SlotSelection() {
  return (
    <>
        {/* <AppointmentForm />  */}
        {console.log("Inside the slot selection")}
        <AvailableSlots />
    </>
  )
}

export default SlotSelection;
