
export const section1Content = {
    // MainBG,
    title: "Welcome to unity",
    subtitle: "A platform where ideas meet innoators",
  };