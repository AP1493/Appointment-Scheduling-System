const doctor = require('./doctor')
const patient = require('./patient')
const appointment = require('./appointment')

module.exports = {

    doctor,
    patient,
    appointment
}