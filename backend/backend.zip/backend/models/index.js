const Patient = require('./Patient')
const Doctor = require('./Doctor')
const Appointment = require('./Appointment')

module.exports = {

    Patient,
    Doctor,
    Appointment
}